package main

import (
	"fmt"
	"math"

	"github.com/lf-edge/ekuiper/pkg/api"
)

type fftFunc struct{}

func (f *fftFunc) Validate(args []interface{}) error {
	if len(args) != 1 {
		return fmt.Errorf("fft expects one argument of type []float64")
	}
	_, ok := args[0].([]float64)
	if !ok {
		return fmt.Errorf("argument must be []float64")
	}
	return nil
}

func (f *fftFunc) Exec(args []interface{}, ctx api.FunctionContext) (interface{}, bool) {
	input, _ := args[0].([]float64)
	n := len(input)
	real := make([]float64, n)
	imag := make([]float64, n)
	mag := make([]float64, n)

	for k := 0; k < n; k++ {
		for t := 0; t < n; t++ {
			angle := 2 * math.Pi * float64(t) * float64(k) / float64(n)
			real[k] += input[t] * math.Cos(angle)
			imag[k] -= input[t] * math.Sin(angle)
		}
		mag[k] = math.Sqrt(real[k]*real[k] + imag[k]*imag[k])
	}

	return mag, true
}

func (f *fftFunc) IsAggregate() bool {
	return false
}

func (f *fftFunc) GetName() string {
	return "fft"
}

var Fft fftFunc
